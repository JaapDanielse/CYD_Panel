User_Setup.h ReadMe.txt

The User_Setup.h is a configuration file for the TFT_eSPI library by Bodmer for use with the CYD_Panel library.
See instruction on https://github.com/JaapDanielse/CYD_Panel/wiki/Getting-Started
